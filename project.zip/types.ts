export interface Professor {
  id: number;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  password: string;
  isAdmin: boolean;
  classes?: Class[];
}

export interface Program {
  id: number;
  name: string;
  classes?: Class[];
}

export interface Class {
  id: number;
  name: string;
  programId: number;
  program?: Program;
  students?: Student[];
  createdAt: string | Date;
  updatedAt: string | Date;
}

export interface Student {
  id: number;
  firstName: string;
  lastName: string;
  classId: number;
  class?: Class;
  attendance?: Attendance[];
}

export interface Lecture {
  id: number;
  date: string | Date;
  attendance?: Attendance[];
}

export interface Attendance {
  id: number;
  studentId: number;
  student?: Student;
  lectureId: number;
  lecture?: Lecture;
  status: AttendanceStatus;
}

export enum AttendanceStatus {
  PRESENT = "PRESENT",
  ABSENT = "ABSENT",
  PARTICIPATED = "PARTICIPATED",
}

export interface AttendanceRecord {
  id: number;
  firstName: string;
  lastName: string;
  status: AttendanceStatus;
}

export interface StudentReport {
  id: number;
  firstName: string;
  lastName: string;
  presence: number;
  absence: number;
  participation: number;
}
